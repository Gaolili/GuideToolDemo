//
//  VersionTool.h
//  LearnDemo
//
//  Created by gaolili on 16/8/2.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VersionTool : NSObject
+ (BOOL)shouldPresentIntroVC;
+ (void)hasShowedInstro;
@end
