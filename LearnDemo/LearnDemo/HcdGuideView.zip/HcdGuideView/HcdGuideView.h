//
//  HcdGuideView.h
//  HcdGuideViewDemo
//
//  Created by polesapp-hcd on 16/7/12.
//  Copyright © 2016年 Polesapp. All rights reserved.
//

#define kHcdGuideViewBounds [UIScreen mainScreen].bounds

#import "HcdGuideViewManager.h"
#import "HcdGuideViewCell.h"